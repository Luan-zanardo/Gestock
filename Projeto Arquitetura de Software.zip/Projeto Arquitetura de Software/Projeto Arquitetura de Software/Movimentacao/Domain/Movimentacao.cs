﻿
namespace Projeto_Arquitetura_de_Software.Movimentacao.Domain
{
    public enum TipoMovimentacao
    {
        Entrada,
        Saida
    }

    public class Movimentacao
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public Guid ProdutoId { get; set; }
        public Guid FornecedorId { get; set; }
        public int Quantidade { get; set; }
        public DateTime Data { get; set; }
        public TipoMovimentacao Tipo { get; set; }
        public string? Observacao { get; set; }
    }
}
