﻿namespace Projeto_Arquitetura_de_Software.Movimentacao.DTO
{
    public class AtualizarMovimentacaoDTO
    {
        public required int ProdutoID { get; set; }
        public required int Quantidade { get; set; }
        public required TipoMovimentacao Tipo { get; set; }
        public string? Observacao { get; set; }

        public enum TipoMovimentacao
        {
            Entrada,
            Saida
        }
    }
}