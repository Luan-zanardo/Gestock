﻿namespace Projeto_Arquitetura_de_Software.Movimentacao.DTO
{
    public class BuscarMovimentacaoDTO
    {
        public Guid Id { get; set; }
        public required int ProdutoID { get; set; }
        public int Quantidade { get; set; }
        public DateTime Data {  get; set; }
        public string? Tipo { get; set; }
        public string? Observacao { get; set; }

    }
}