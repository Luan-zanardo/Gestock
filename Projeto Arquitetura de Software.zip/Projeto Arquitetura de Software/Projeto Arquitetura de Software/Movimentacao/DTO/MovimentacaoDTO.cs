﻿using Projeto_Arquitetura_de_Software.Movimentacao.Domain;
using System;

namespace Projeto_Arquitetura_de_Software.Movimentacao.DTO
{
    public abstract class BaseMovimentacaoDTO
    {
        public required Guid ProdutoId { get; set; }
        public required Guid FornecedorId { get; set; }
        public required int Quantidade { get; set; }
        public required TipoMovimentacao Tipo { get; set; }
        public string? Observacao { get; set; }
    }

    public class InserirMovimentacaoDTO : BaseMovimentacaoDTO { }

    public class AtualizarMovimentacaoDTO : BaseMovimentacaoDTO
    {
        public required Guid Id { get; set; }
        public required DateTime Data { get; set; }
    }

    public class BuscarMovimentacaoDTO : BaseMovimentacaoDTO
    {
        public required Guid Id { get; set; }
        public required DateTime Data { get; set; }
    }
}
