﻿using System;
using System.Collections.Generic;
using System.Linq;
using Projeto_Arquitetura_de_Software.Data;
using Projeto_Arquitetura_de_Software.Movimentacao.DTO;
using Projeto_Arquitetura_de_Software.Movimentacao.Infra;
using MovimentacaoDomain = Projeto_Arquitetura_de_Software.Movimentacao.Domain.Movimentacao;
using TipoMovimentacao = Projeto_Arquitetura_de_Software.Movimentacao.Domain.TipoMovimentacao;

namespace Projeto_Arquitetura_de_Software.Movimentacao.Service
{
    public class MovimentacaoService
    {
        private readonly AppDbContext _dataContext;

        public MovimentacaoService()
        {
            _dataContext = GeradorDeServicos.ServiceProvider!
                .GetRequiredService<AppDbContext>();
        }

        public MovimentacaoDomain Inserir(InserirMovimentacaoDTO dto)
        {
            if (dto.Quantidade <= 0)
                throw new ArgumentException("A quantidade deve ser maior que zero.");

            var produto = _dataContext.Produtos.FirstOrDefault(p => p.Id == dto.ProdutoId)
                          ?? throw new ArgumentException("Produto não encontrado.");

            var fornecedor = _dataContext.Fornecedores.FirstOrDefault(f => f.Id == dto.FornecedorId)
                            ?? throw new ArgumentException("Fornecedor não encontrado.");

            if (dto.Tipo == TipoMovimentacao.Saida && produto.Estoque < dto.Quantidade)
                throw new InvalidOperationException("Estoque insuficiente.");

            if (dto.Tipo == TipoMovimentacao.Entrada)
                produto.Estoque += dto.Quantidade;
            else
                produto.Estoque -= dto.Quantidade;

            var movimentacao = new MovimentacaoDomain
            {
                ProdutoId = dto.ProdutoId,
                FornecedorId = dto.FornecedorId,
                Quantidade = dto.Quantidade,
                Observacao = dto.Observacao,
                Data = DateTime.UtcNow,
                Tipo = dto.Tipo
            };

            _dataContext.Movimentacoes.Add(movimentacao);
            _dataContext.SaveChanges();

            return movimentacao;
        }

        public MovimentacaoDomain? BuscarPorId(Guid id)
        {
            return _dataContext.Movimentacoes.FirstOrDefault(m => m.Id == id);
        }

        public List<MovimentacaoDomain> Listar()
        {
            return _dataContext.Movimentacoes.ToList();
        }

        public MovimentacaoDomain Atualizar(Guid id, InserirMovimentacaoDTO dto)
        {
            var movimentacao = _dataContext.Movimentacoes.FirstOrDefault(m => m.Id == id)
                                ?? throw new InvalidOperationException("Movimentação não encontrada.");

            var produto = _dataContext.Produtos.FirstOrDefault(p => p.Id == movimentacao.ProdutoId)
                          ?? throw new InvalidOperationException("Produto não encontrado.");


            if (movimentacao.Tipo == TipoMovimentacao.Entrada)
                produto.Estoque -= movimentacao.Quantidade;
            else
                produto.Estoque += movimentacao.Quantidade;

            if (dto.Tipo == TipoMovimentacao.Saida && produto.Estoque < dto.Quantidade)
                throw new InvalidOperationException("Estoque insuficiente.");

            movimentacao.ProdutoId = dto.ProdutoId;
            movimentacao.FornecedorId = dto.FornecedorId;
            movimentacao.Quantidade = dto.Quantidade;
            movimentacao.Tipo = dto.Tipo;
            movimentacao.Observacao = dto.Observacao;
            movimentacao.Data = DateTime.UtcNow;

            if (dto.Tipo == TipoMovimentacao.Entrada)
                produto.Estoque += dto.Quantidade;
            else
                produto.Estoque -= dto.Quantidade;

            _dataContext.SaveChanges();

            return movimentacao;
        }

        public void Remover(Guid id)
        {
            var movimentacao = _dataContext.Movimentacoes.FirstOrDefault(m => m.Id == id)
                                ?? throw new InvalidOperationException("Movimentação não encontrada.");

            var produto = _dataContext.Produtos.FirstOrDefault(p => p.Id == movimentacao.ProdutoId)
                          ?? throw new InvalidOperationException("Produto não encontrado.");

            if (movimentacao.Tipo == TipoMovimentacao.Entrada)
                produto.Estoque -= movimentacao.Quantidade;
            else
                produto.Estoque += movimentacao.Quantidade;

            _dataContext.Movimentacoes.Remove(movimentacao);
            _dataContext.SaveChanges();
        }
    }
}
