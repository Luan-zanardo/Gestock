﻿namespace Projeto_Arquitetura_de_Software.Movimentacao.Services
{
    public class Movimentacao
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public required int ProdutoID { get; set; }
        public int Quantidade { get; set; }
        public DateTime Data { get; set; }
        public required TipoMovimentacao Tipo { get; set; }
        public string? Observação { get; set; }

    public enum TipoMovimentacao
        {
            Entrada,
            Saída
        }
        
    }
}