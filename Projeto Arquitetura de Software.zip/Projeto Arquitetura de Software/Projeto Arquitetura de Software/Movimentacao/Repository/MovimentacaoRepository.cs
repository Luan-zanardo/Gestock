﻿using Microsoft.AspNetCore.Mvc;
using Projeto_Arquitetura_de_Software.Movimentacao.Service;
using Projeto_Arquitetura_de_Software.Movimentacao.DTO;

namespace Projeto_Arquitetura_de_Software.Movimentacao.Repository
{
    [ApiController]
    [Route("api/movimentacoes")]
    public class MovimentacaoRepository : ControllerBase
    {
        private readonly MovimentacaoService _service;

        public MovimentacaoRepository()
        {
            _service = new MovimentacaoService();
        }

        [HttpPost]
        public IActionResult Inserir([FromBody] InserirMovimentacaoDTO dto)
        {
            try
            {
                var movimentacao = _service.Inserir(dto);
                return Ok(movimentacao);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public IActionResult BuscarTodas()
        {
            return Ok(_service.Listar());
        }

        [HttpGet("{id}")]
        public IActionResult BuscarPorId(Guid id)
        {
            var movimentacao = _service.BuscarPorId(id);

            if (movimentacao == null)
                return NotFound("Movimentação não encontrada.");

            return Ok(movimentacao);
        }

        [HttpPut("{id}")]
        public IActionResult Atualizar(Guid id, [FromBody] InserirMovimentacaoDTO dto)
        {
            try
            {
                var movimentacao = _service.Atualizar(id, dto);
                return Ok(movimentacao);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Remover(Guid id)
        {
            try
            {
                _service.Remover(id);
                return NoContent();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
