﻿using Microsoft.EntityFrameworkCore;
using Projeto_Arquitetura_de_Software.Movimentacao.Services;

namespace Projeto_Arquitetura_de_Software.Movimentacao.Infra
{
    public static class GeradorDeServicos
    {
        public static ServiceProvider? ServiceProvider;

        public static MovimentacaoDataContext CarregarContexto()
        {
            if (ServiceProvider is null)
                throw new InvalidOperationException("ServiceProvider não foi inicializado.");

            return ServiceProvider.GetRequiredService<MovimentacaoDataContext>();
        }
    }
    public class MovimentacaoDataContext : DbContext
    {
        public MovimentacaoDataContext(DbContextOptions<MovimentacaoDataContext> options)
            : base(options)
        { }

        public DbSet<Services.Movimentacao> Fornecedores { get; set; } = null!;
    }
}