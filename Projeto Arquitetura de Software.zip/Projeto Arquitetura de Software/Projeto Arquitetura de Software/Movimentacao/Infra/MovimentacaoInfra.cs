﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MovimentacaoEntity = Projeto_Arquitetura_de_Software.Movimentacao.Domain.Movimentacao;

namespace Projeto_Arquitetura_de_Software.Movimentacao.Infra
{
    public static class GeradorDeServicos
    {
        public static ServiceProvider? ServiceProvider;

        public static MovimentacaoDataContext CarregarContexto()
        {
            if (ServiceProvider is null)
                throw new InvalidOperationException("ServiceProvider não foi inicializado.");

            return ServiceProvider.GetRequiredService<MovimentacaoDataContext>();
        }
    }

    public class MovimentacaoDataContext : DbContext
    {
        public MovimentacaoDataContext(DbContextOptions<MovimentacaoDataContext> options)
            : base(options)
        { }

        public DbSet<MovimentacaoEntity> Movimentacoes { get; set; } = null!;
    }
}
