﻿using Microsoft.EntityFrameworkCore;
using Projeto_Arquitetura_de_Software.Produtos.DTO;
using Projeto_Arquitetura_de_Software.Fornecedor.Service;
using Projeto_Arquitetura_de_Software.Movimentacao.Services;

namespace Projeto_Arquitetura_de_Software.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Fornecedor.Service.Fornecedor> Fornecedores { get; set; } = null!;
        public DbSet<InserirProdutoDTO> Produtos { get; set; } = null!;
        public DbSet<Movimentacao.Services.Movimentacao> Movimentacoes { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Fornecedor.Service.Fornecedor>().HasKey(f => f.Id);
            modelBuilder.Entity<InserirProdutoDTO>().HasKey(p => p.Id);
            modelBuilder.Entity<Movimentacao.Services.Movimentacao>().HasKey(m => m.Id);

            base.OnModelCreating(modelBuilder);
        }
    }
}
