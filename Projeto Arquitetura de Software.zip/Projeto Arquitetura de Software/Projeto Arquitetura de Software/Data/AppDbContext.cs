﻿using Microsoft.EntityFrameworkCore;
using FornecedorEntity = Projeto_Arquitetura_de_Software.Fornecedor.Domain.Fornecedor;
using ProdutoEntity = Projeto_Arquitetura_de_Software.Produtos.Domain.Produto;
using MovimentacaoEntity = Projeto_Arquitetura_de_Software.Movimentacao.Domain.Movimentacao;

namespace Projeto_Arquitetura_de_Software.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<FornecedorEntity> Fornecedores { get; set; }
        public DbSet<ProdutoEntity> Produtos { get; set; }
        public DbSet<MovimentacaoEntity> Movimentacoes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FornecedorEntity>().HasKey(f => f.Id);
            modelBuilder.Entity<ProdutoEntity>().HasKey(p => p.Id);
            modelBuilder.Entity<MovimentacaoEntity>().HasKey(m => m.Id);

            base.OnModelCreating(modelBuilder);
        }
    }
}
