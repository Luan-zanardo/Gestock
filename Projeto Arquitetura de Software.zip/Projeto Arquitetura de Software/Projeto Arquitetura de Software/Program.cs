using Microsoft.EntityFrameworkCore;
using Projeto_Arquitetura_de_Software.Data;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.Json.Serialization.Metadata;

var builder = WebApplication.CreateBuilder(args);

builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.TypeInfoResolverChain.Insert(0, AppJsonSerializerContext.Default);
});

builder.Services.AddControllers();

builder.Services.AddOpenApi();

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.MapControllers();

app.Run();

internal partial class AppJsonSerializerContext : JsonSerializerContext
{
    public AppJsonSerializerContext(JsonSerializerOptions? options) : base(options)
    {
    }

    public static IJsonTypeInfoResolver Default { get; internal set; } = new DefaultJsonTypeInfoResolver();

    protected override JsonSerializerOptions? GeneratedSerializerOptions => throw new NotImplementedException();

    public override JsonTypeInfo? GetTypeInfo(Type type)
    {
        throw new NotImplementedException();
    }
}
