﻿using Projeto_Arquitetura_de_Software.Data;
using Projeto_Arquitetura_de_Software.Fornecedor.DTO;
using Projeto_Arquitetura_de_Software.Fornecedor.Infra;

namespace Projeto_Arquitetura_de_Software.Fornecedor.Service
{
    public class FornecedorService
    {
        public AppDbContext _dataContext;

        public FornecedorService()
        {
            _dataContext = FornecedorDataContext.CarregarContexto();
        }

        public Fornecedor Inserir(InserirFornecedorDTO dadosInsercao)
        {
            if (string.IsNullOrWhiteSpace(dadosInsercao.Nome))
                throw new ArgumentException("O nome é obrigatório.");
            if (string.IsNullOrWhiteSpace(dadosInsercao.Email))
                throw new ArgumentException("O email é obrigatório.");
            if (string.IsNullOrWhiteSpace(dadosInsercao.Telefone))
                throw new ArgumentException("O telefone é obrigatório.");
            if (string.IsNullOrWhiteSpace(dadosInsercao.CNPJ))
                throw new ArgumentException("O CNPJ é obrigatório.");

            if (_dataContext.Fornecedores.Any(p => p.CNPJ == dadosInsercao.CNPJ))
                throw new InvalidOperationException("Já existe um fornecedor cadastrado com esse CNPJ.");

            var fornecedor = new Fornecedor
            {
                Nome = dadosInsercao.Nome,
                Email = dadosInsercao.Email,
                Telefone = dadosInsercao.Telefone,
                CNPJ = dadosInsercao.CNPJ,
                Endereco = dadosInsercao.Endereco,
                Cidade = dadosInsercao.Cidade,
                Estado = dadosInsercao.Estado,
                Ramo = dadosInsercao.Ramo
            };

            _dataContext.Add(fornecedor);
            _dataContext.SaveChanges();

            return fornecedor;
        }

        public Fornecedor Atualizar(Guid id, AtualizarFornecedorDTO dadosAlteracao)
        {
            var fornecedor = _dataContext.Fornecedores.FirstOrDefault(p => p.Id == id);

            if (fornecedor == null)
                throw new InvalidOperationException("Fornecedor não encontrado.");

            fornecedor.Nome = dadosAlteracao.Nome;
            fornecedor.Email = dadosAlteracao.Email;
            fornecedor.CNPJ = dadosAlteracao.CNPJ;
            fornecedor.Endereco = dadosAlteracao.Endereco;
            fornecedor.Cidade = dadosAlteracao.Cidade;
            fornecedor.Estado = dadosAlteracao.Estado;
            fornecedor.Ramo = dadosAlteracao.Ramo;

            _dataContext.SaveChanges();

            return fornecedor;
        }

        public List<Fornecedor> BuscarFornecedor()
        {
            return _dataContext.Fornecedores.ToList();
        }

        public Fornecedor BuscarPorId(Guid id)
        {
            return _dataContext.Fornecedores.FirstOrDefault(p => p.Id == id);
        }
    }
}