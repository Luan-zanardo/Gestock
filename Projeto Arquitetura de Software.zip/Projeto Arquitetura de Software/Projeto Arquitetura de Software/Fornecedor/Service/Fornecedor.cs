﻿namespace Projeto_Arquitetura_de_Software.Fornecedor.Service
{
    public class Fornecedor
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public required string Nome { get; set; }
        public required string Email { get; set; }
        public required string Telefone { get; set; }
        public required string CNPJ { get; set; }
        public string? Endereco { get; set; }
        public string? Cidade { get; set; }
        public string? Estado { get; set; }
        public string? Ramo { get; set; }
        public DateTime DataCadastro { get; set; } = DateTime.Now;

    }
}