﻿using Microsoft.AspNetCore.Mvc;
using Projeto_Arquitetura_de_Software.Fornecedor.DTO;
using Projeto_Arquitetura_de_Software.Fornecedor.Service;

namespace Projeto_Arquitetura_de_Software.Fornecedor.Repository
{
    [ApiController]
    [Route("api/fornecedores")]
    public class FornecedorRepository : BaseFornecedorDTO
    {
        private readonly FornecedorService _service;

        public FornecedorRepository()
        {
            _service = new FornecedorService();
        }

        [HttpPost]
        public IActionResult Inserir([FromBody] InserirFornecedorDTO dto)
        {
            var fornecedor = _service.Inserir(dto);
            return Ok(fornecedor);
        }

        [HttpPut("{id}")]
        public IActionResult Atualizar(Guid id, [FromBody] AtualizarFornecedorDTO dto)
        {
            var fornecedor = _service.Atualizar(id, dto);
            return Ok(fornecedor);
        }

        [HttpGet]
        public IActionResult BuscarTodos()
        {
            return Ok(_service.BuscarFornecedor());
        }

        [HttpGet("{id}")]
        public IActionResult BuscarPorId(Guid id)
        {
            var fornecedor = _service.BuscarPorId(id);
            if (fornecedor == null)
                return NotFound("Fornecedor não encontrado.");

            return Ok(fornecedor);
        }

        [HttpDelete("{id}")]
        public IActionResult Remover(Guid id)
        {
            var fornecedor = _service.BuscarPorId(id);

            if (fornecedor == null)
                return NotFound("Fornecedor não encontrado.");

            _service._dataContext.Remove(fornecedor);
            _service._dataContext.SaveChanges();

            return NoContent();
        }
    }
}
