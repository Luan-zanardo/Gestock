﻿using System.ComponentModel.DataAnnotations;

namespace Projeto_Arquitetura_de_Software.Fornecedor.DTO
{
    public class BaseFornecedorDTO
    {
        public required string Nome { get; set; }
        public required string Email { get; set; }
        public required string Telefone { get; set; }
        public required string CNPJ { get; set; }
        public string? Endereco { get; set; }
        public string? Cidade { get; set; }
        public string? Estado { get; set; }
        public string? Ramo { get; set; }
    }
    public class AtualizarFornecedorDTO : BaseFornecedorDTO
    {
        public required Guid Id { get; set; }
    }
    public class InserirFornecedorDTO : BaseFornecedorDTO{ }

    public class BuscarFornecedorDTO : BaseFornecedorDTO
    {
        public required Guid Id { get; set; }
        public DateTime DataCadastro { get; set; }
    }
}