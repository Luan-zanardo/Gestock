﻿using Projeto_Arquitetura_de_Software.Produtos.Domain;

namespace Projeto_Arquitetura_de_Software.Fornecedor.Domain
{
    public class Fornecedor
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Nome { get; set; } = null!;
        public string Email { get; set; } = null!;
        public string Telefone { get; set; } = null!;
        public string CNPJ { get; set; } = null!;
        public string? Endereco { get; set; }
        public string? Cidade { get; set; }
        public string? Estado { get; set; }
        public string? Ramo { get; set; }
        public ICollection<Produto>? Produtos { get; set; }
    }
}
