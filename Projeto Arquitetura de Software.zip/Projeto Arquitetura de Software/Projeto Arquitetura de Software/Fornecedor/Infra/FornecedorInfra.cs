﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Projeto_Arquitetura_de_Software.Data;

using FornecedorEntity = Projeto_Arquitetura_de_Software.Fornecedor.Domain.Fornecedor;

namespace Projeto_Arquitetura_de_Software.Fornecedor.Infra
{
    public static class GeradorDeServicos
    {
        public static ServiceProvider? ServiceProvider;

        public static FornecedorDataContext CarregarContexto()
        {
            if (ServiceProvider is null)
                throw new InvalidOperationException("ServiceProvider não foi inicializado.");

            return ServiceProvider.GetRequiredService<FornecedorDataContext>();
        }
    }

    public class FornecedorDataContext : DbContext
    {
        public FornecedorDataContext(DbContextOptions<FornecedorDataContext> options)
            : base(options)
        { }

        public DbSet<FornecedorEntity> Fornecedores { get; set; } = null!;
    }
}
