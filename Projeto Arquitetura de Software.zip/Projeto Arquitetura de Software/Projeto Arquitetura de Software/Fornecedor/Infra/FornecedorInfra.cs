﻿using Microsoft.EntityFrameworkCore;
using Projeto_Arquitetura_de_Software.Data;
using Projeto_Arquitetura_de_Software.Fornecedor.Service;

namespace Projeto_Arquitetura_de_Software.Fornecedor.Infra
{
    public static class GeradorDeServicos
    {
        public static ServiceProvider? ServiceProvider;

        public static FornecedorDataContext CarregarContexto()
        {
            if (ServiceProvider is null)
                throw new InvalidOperationException("ServiceProvider não foi inicializado.");

            return ServiceProvider.GetRequiredService<FornecedorDataContext>();
        }
    }

    public class FornecedorDataContext : DbContext
    {
        public FornecedorDataContext(DbContextOptions<FornecedorDataContext> options)
            : base(options)
        { }

        public DbSet<Service.Fornecedor> Fornecedores { get; set; } = null!;

        internal static AppDbContext? CarregarContexto()
        {
            throw new NotImplementedException();
        }
    }
}