﻿namespace Projeto_Arquitetura_de_Software.Produtos.Service
{
    public class Produto
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public required string Nome { get; set; }
        public string? Descricao { get; set; }
        public required int Quantidade { get; set; }
        public required decimal Preco { get; set; }
        public required int FornecedorId { get; set; }
    }
}