﻿using Projeto_Arquitetura_de_Software.Data;
using Projeto_Arquitetura_de_Software.Produtos.Domain;
using Projeto_Arquitetura_de_Software.Produtos.DTO;
using Projeto_Arquitetura_de_Software.Fornecedor.Infra;
using Microsoft.EntityFrameworkCore;

namespace Projeto_Arquitetura_de_Software.Produtos.Service
{
    public class ProdutoService
    {
        public FornecedorDataContext _context;

        public ProdutoService()
        {
            _context = GeradorDeServicos.CarregarContexto();
        }

        public Produto Inserir(InserirProdutoDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Nome))
                throw new ArgumentException("O nome do produto é obrigatório.");

            var produto = new Produto
            {
                Nome = dto.Nome,
                Descricao = dto.Descricao,
                Estoque = dto.Estoque,
                Categoria = dto.Categoria,
                Preco = dto.Preco,
                FornecedorId = dto.FornecedorId
            };

            _context.Produtos.Add(produto);
            _context.SaveChanges();

            return produto;
        }

        public Produto Atualizar(Guid id, AtualizarProdutoDTO dto)
        {
            var produto = _context.Produtos.FirstOrDefault(p => p.Id == id);

            if (produto == null)
                throw new InvalidOperationException("Produto não encontrado.");

            produto.Nome = dto.Nome;
            produto.Descricao = dto.Descricao;
            produto.Estoque = dto.Estoque;
            produto.Categoria = dto.Categoria;
            produto.Preco = dto.Preco;
            produto.FornecedorId = dto.FornecedorId;

            _context.SaveChanges();

            return produto;
        }

        public List<Produto> BuscarTodos()
        {
            return _context.Produtos.ToList();
        }

        public Produto BuscarPorId(Guid id)
        {
            return _context.Produtos.FirstOrDefault(p => p.Id == id);
        }

        public List<Produto> BuscarPorFornecedor(Guid fornecedorId)
        {
            return _context.Produtos
                .Where(p => p.FornecedorId == fornecedorId).ToList();
        }

        public void Remover(Guid id)
        {
            var produto = _context.Produtos.FirstOrDefault(p => p.Id == id);

            if (produto == null)
                throw new InvalidOperationException("Produto não encontrado.");

            _context.Remove(produto);
            _context.SaveChanges();
        }
    }
}
