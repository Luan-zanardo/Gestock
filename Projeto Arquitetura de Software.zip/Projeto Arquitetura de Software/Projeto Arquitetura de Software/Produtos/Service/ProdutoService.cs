﻿using Projeto_Arquitetura_de_Software.Data;
using Projeto_Arquitetura_de_Software.Produtos.DTO;
using Projeto_Arquitetura_de_Software.Produtos.Infra;

namespace Projeto_Arquitetura_de_Software.Produtos.Service
{
    public class ProdutoService
    {
        public AppDbContext _dataContext;

        public ProdutoService()
        {
            _dataContext = ProdutosDataContext.CarregarContexto();
        }

        public Produto Inserir(InserirProdutoDTO dadosInsercao)
        {
            if (string.IsNullOrWhiteSpace(dadosInsercao.Nome))
                throw new ArgumentException("O nome do produto é obrigatório.");
            if (dadosInsercao.Preco <= 0)
                throw new ArgumentException("O preço deve ser maior que zero.");
            if (dadosInsercao.Estoque < 0)
                throw new ArgumentException("O estoque não pode ser negativo.");

            if (_dataContext.Produtos.Any(p => p.Nome == dadosInsercao.Nome))
                throw new InvalidOperationException("Já existe um produto cadastrado com esse nome.");

            var produto = new Produto
            {
                Nome = dadosInsercao.Nome,
                Preco = dadosInsercao.Preco,
                Estoque = dadosInsercao.Estoque,
                Categoria = dadosInsercao.Categoria,
                Descricao = dadosInsercao.Descricao
            };

            _dataContext.Add(produto);
            _dataContext.SaveChanges();

            return produto;
        }

        public Produto Atualizar(Guid id, AtualizarProdutoDTO dadosAlteracao)
        {
            var produto = _dataContext.Produtos.FirstOrDefault(p => p.Id == id);

            if (produto == null)
                throw new InvalidOperationException("Produto não encontrado.");

            produto.Nome = dadosAlteracao.Nome;
            produto.Preco = dadosAlteracao.Preco;
            produto.Estoque = dadosAlteracao.Estoque;
            produto.Categoria = dadosAlteracao.Categoria;
            produto.Descricao = dadosAlteracao.Descricao;

            _dataContext.SaveChanges();

            return produto;
        }

        public List<Produto> BuscarProdutos()
        {
            return _dataContext.Produtos.ToList();
        }

        public Produto BuscarPorId(Guid id)
        {
            return _dataContext.Produtos.FirstOrDefault(p => p.Id == id);
        }
    }
}
