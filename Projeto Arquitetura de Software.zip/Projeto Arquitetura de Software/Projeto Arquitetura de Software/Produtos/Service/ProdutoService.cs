﻿using Projeto_Arquitetura_de_Software.Data;
using Projeto_Arquitetura_de_Software.Fornecedor.Infra;
using Projeto_Arquitetura_de_Software.Produtos.Infra;

namespace Projeto_Arquitetura_de_Software.Produtos.Service
{
    public class ProdutoService
    {
        public AppDbContext _dataContext;

        public ProdutoService()
        {
            _dataContext = ProdutosDataContext.CarregarContexto();
        }
    }
}