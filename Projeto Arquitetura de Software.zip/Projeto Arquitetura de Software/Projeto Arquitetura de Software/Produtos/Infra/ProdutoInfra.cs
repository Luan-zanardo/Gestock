﻿using Microsoft.EntityFrameworkCore;
using Projeto_Arquitetura_de_Software.Data;   

namespace Projeto_Arquitetura_de_Software.Produtos.Infra
{
    public static class GeradorDeServicos
    {
        public static ServiceProvider? ServiceProvider;

        public static ProdutosDataContext CarregarContexto()
        {
            if (ServiceProvider is null)
                throw new InvalidOperationException("ServiceProvider não foi inicializado.");

            return ServiceProvider.GetRequiredService<ProdutosDataContext>();
        }
    }

    public class ProdutosDataContext : DbContext
    {
        public ProdutosDataContext(DbContextOptions<ProdutosDataContext> options)
            : base(options)
        { }

        public DbSet<DTO.InserirProdutoDTO> Produtos { get; set; } = null!;

        internal static AppDbContext? CarregarContexto()
        {
            throw new NotImplementedException();
        }
    }
}