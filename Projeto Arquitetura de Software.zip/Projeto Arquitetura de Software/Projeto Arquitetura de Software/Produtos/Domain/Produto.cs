﻿using Projeto_Arquitetura_de_Software.Fornecedor.Domain;

namespace Projeto_Arquitetura_de_Software.Produtos.Domain
{
    public class Produto
    {
        public Guid Id { get; set; } = Guid.NewGuid();
        public string Nome { get; set; } = null!;
        public string? Descricao { get; set; }
        public int Estoque { get; set; }
        public string Categoria { get; set; } = null!;
        public decimal Preco { get; set; }
        public Guid FornecedorId { get; set; }
        public Projeto_Arquitetura_de_Software.Fornecedor.Domain.Fornecedor Fornecedor { get; set; } = null!;
    }
}
