﻿namespace Projeto_Arquitetura_de_Software.Produtos.DTO
{
    public abstract class BaseProdutoDTO
    {
        public required string Nome { get; set; }
        public string? Descricao { get; set; }
        public required int Quantidade { get; set; }
        public required decimal Preco { get; set; }
    }
    public class AtualizarProdutoDTO : BaseProdutoDTO{
        public required Guid Id { get; set; }
        public required int FornecedorId { get; set; }
    }

    public class InserirProdutoDTO : BaseProdutoDTO{
        internal object? Id;

        public required int FornecedorId { get; set; }
    }

    public class BuscarProdutoDTO : BaseProdutoDTO{ 
        public required Guid Id { get; set; }
    }
}