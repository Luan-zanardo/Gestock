﻿using Microsoft.AspNetCore.Mvc;
using Projeto_Arquitetura_de_Software.Produtos.Service;
using Projeto_Arquitetura_de_Software.Produtos.DTO;

namespace Projeto_Arquitetura_de_Software.Produtos.Repository
{
    [ApiController]
    [Route("api/produtos")]
    public class ProdutoRepository : ControllerBase
    {
        private readonly ProdutoService _service;

        public ProdutoRepository()
        {
            _service = new ProdutoService();
        }

        [HttpPost]
        public IActionResult Inserir([FromBody] InserirProdutoDTO dto)
        {
            var produto = _service.Inserir(dto);
            return Ok(produto);
        }

        [HttpPut("{id}")]
        public IActionResult Atualizar(Guid id, [FromBody] AtualizarProdutoDTO dto)
        {
            var produto = _service.Atualizar(id, dto);
            return Ok(produto);
        }

        [HttpGet]
        public IActionResult BuscarTodos()
        {
            return Ok(_service.BuscarTodos());
        }

        [HttpGet("{id}")]
        public IActionResult BuscarPorId(Guid id)
        {
            var produto = _service.BuscarPorId(id);

            if (produto == null)
                return NotFound("Produto não encontrado.");

            return Ok(produto);
        }

        // Aqui está uma das duas comunicações simples entre os micros
        [HttpGet("fornecedor/{fornecedorId}")]
        public IActionResult BuscarPorFornecedor(Guid fornecedorId)
        {
            var produtos = _service.BuscarPorFornecedor(fornecedorId);

            if (produtos == null || produtos.Count == 0)
                return NotFound("Nenhum produto encontrado para este fornecedor.");

            return Ok(produtos);
        }

        [HttpDelete("{id}")]
        public IActionResult Remover(Guid id)
        {
            try
            {
                _service.Remover(id);
                return NoContent();
            }
            catch
            {
                return NotFound("Produto não encontrado.");
            }
        }
    }
}
